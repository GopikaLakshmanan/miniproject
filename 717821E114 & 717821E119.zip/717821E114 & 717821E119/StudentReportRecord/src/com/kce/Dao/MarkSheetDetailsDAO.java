package com.kce.Dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;
import com.kce.bean.MarkSheetDetails;
import com.kce.util.DButil;

public class MarkSheetDetailsDAO {
	static Scanner sc = new Scanner(System.in);
	public static void Student(MarkSheetDetails md) {
	try {
	Connection con = DButil.getConnection();
	PreparedStatement stmt = con.prepareStatement("INSERT INTO studentdetails (subject, grade) VALUES (?, ?)");
	stmt.setString(1, md.getSubject());
	stmt.setDouble(2, md.getGrade());
	stmt.executeUpdate();
	System.out.println("Data inserted successfully!");
	} catch (SQLException e) {
	System.out.println("Error: " + e.getMessage());
	}
	}
	public static void update() {
	try {
	Connection con = DButil.getConnection();
	PreparedStatement stmt = con.prepareStatement("UPDATE studentdetails SET grade = ? WHERE subject = ?");
	System.out.println("Enter the grade to be Update: ");
	double grade = sc.nextDouble();
	System.out.println("Enter the new Student Grade: ");
	String subject = sc.next();
	stmt.setDouble(1, grade);
	stmt.setString(2, subject);
	int rowsAffected = stmt.executeUpdate();
	if (rowsAffected > 0) {
	System.out.println("Update successful");
	} else {
	System.out.println("No records found for the given subject");
	}
	} catch (SQLException e) {
	System.out.println("Error: " + e.getMessage());
	}
	}
	public static void deleteRows() {
	try {
	Connection con = DButil.getConnection();
	PreparedStatement stmt = con.prepareStatement("TRUNCATE TABLE studentdetails");
	stmt.executeUpdate();
	System.out.println("Table Record is Deleted Successfully");
	} catch (SQLException e) {
	System.out.println(e);
	}
	}
	public static void displayTable() {
	try {
	Connection con = DButil.getConnection();
	PreparedStatement stmt = con.prepareStatement("SELECT * FROM studentdetails");
	ResultSet rs = stmt.executeQuery();
	System.out.println("Student Details:");
	System.out.printf("| %-20s | %-20s |%n", "Subject", "Grade" );
	while (rs.next()) {
	System.out.printf("| %-20s | %-20s |%n",rs.getString(1),rs.getDouble(2));
	}
	rs.close();
	} catch (SQLException e) {
	System.out.println("Error: " + e.getMessage());
	}
	 }
}
