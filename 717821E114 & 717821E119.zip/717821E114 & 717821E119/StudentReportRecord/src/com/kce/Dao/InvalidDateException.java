package com.kce.Dao;
import com.kce.bean.StudentDetails;
import com.kce.util.DButil;
public class InvalidDateException extends Exception{
	public  InvalidDateException(String message) {
		super(message);

}
}
