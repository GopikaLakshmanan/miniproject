package com.kce.Dao;
import com.kce.bean.StudentDetails;
import com.kce.util.DButil;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Scanner;
public class StudentDetailsDAO {
	public static Scanner sc = new Scanner(System.in);

	public static void insert(int a) {
		try {
			StudentDetails[] arr = new StudentDetails[a];
			for (int i = 0; i < a; i++) {
				System.out.println("Enter the Name: ");
				String Name = sc.next();
				System.out.println("Enter the StudentId: ");
				int StudentId = sc.nextInt();
				System.out.println("Enter the EmailId: ");
				String EmailId = sc.next();
				System.out.println("Enter the DateOfBirth(DD/MM/YYYY): ");
				String DateOfBirth=sc.next();
				LocalDate date = validateAndParseDate(DateOfBirth);
				arr[i] = new StudentDetails(Name,StudentId,EmailId,DateOfBirth);
			}
			Connection con = DButil.getConnection();
			PreparedStatement stmt = con.prepareStatement("insert into bus values(?,?,?,?,?,?)");
			for (int i = 0; i < a; i++) {
				stmt.setString(1, arr[i].getName());
				stmt.setInt(2, arr[i].getStudentId());
				stmt.setString(3, arr[i].getEmailId());
				stmt.setString(4, arr[i].getDateOfBirth());
				stmt.executeUpdate();
			}
			System.out.println("Data collected successfully");
		} catch (SQLException e) {
			System.out.println(e);
		} catch (InvalidDateException e) {
			System.out.println(e.getMessage());
		}
	}

	private static LocalDate validateAndParseDate(String DateOfBirth) throws InvalidDateException {
		try {
			return LocalDate.parse(DateOfBirth, DateTimeFormatter.ofPattern("dd/MM/yyyy"));
		} catch (DateTimeParseException e) {
			throw new InvalidDateException("Invalid date format. Please enter the date in the format DD/MM/YYYY.");
		}
	}

	public static void update() {
		try {
			Connection con = DButil.getConnection();
			PreparedStatement stmt = con.prepareStatement("UPDATE studentDetails SET StudentId = ? WHERE Name = ?");
			System.out.println("Enter Name: ");
			String Name = sc.next();
			System.out.println("Enter the StudentId: ");
			int StudentId = sc.nextInt();
			stmt.setInt(1,StudentId );
			stmt.setString(2,Name );
			int rowsAffected = stmt.executeUpdate();

			if (rowsAffected > 0) {
				System.out.println("Update successful");
			} else {
				System.out.println("No records found for the given Name");
			}
		} catch (SQLException e) {
			System.out.println("Error: " + e.getMessage());
		}
	}
	public static void delete() {
		try {
			Connection con = DButil.getConnection();
			PreparedStatement stmt = con.prepareStatement("DELETE FROM studentDetails WHERE Name = ?");
			System.out.println("Enter Name: ");
			String Name = sc.next();
			stmt.setString(1, Name);
			int rowsAffected = stmt.executeUpdate();

			if (rowsAffected > 0) {
				System.out.println("Delete successful");
			} else {
				System.out.println("No records found for the given Name");
			}
		} catch (SQLException e) {
			System.out.println("Error: " + e.getMessage());
		}
	}
	public static void displayTable() {
		try {
			Connection con = DButil.getConnection();
			PreparedStatement stmt = con.prepareStatement("SELECT * FROM studentDetails");
			ResultSet rs = stmt.executeQuery();

			System.out.println("Student Details:");
			System.out.printf("| %-20s | %-20s | %-20s | %-20s |%n", "Name", "StudentId", "EmailId","DateOfBirth ");

			while (rs.next()) {

				System.out.printf("| %-20s | %-20s | %-20s | %-20s |%n",rs.getString(1),rs.getInt(2),rs.getString(3),rs.getString(4));
			}

			rs.close();
		} catch (SQLException e) {
			System.out.println("Error: " + e.getMessage());
		}
	}
	public static String getDateOfBirth(String DateOfBirth) {
		try {
			Connection con = DButil.getConnection();
			PreparedStatement stmt = con.prepareStatement("SELECT Name FROM studentDetails WHERE DateOfBirth = ?");
			stmt.setString(1,DateOfBirth);
			ResultSet rs = stmt.executeQuery();

			if (rs.next()) {
				String Name = rs.getString("Name");
				return Name;
			} else {
				throw new IllegalArgumentException("No records found for the given DateOfBirth");
			}
		} catch (SQLException e) {
			throw new IllegalArgumentException("Error: " + e.getMessage(), e);
		}
	}
		
}

	

	

