package com.kce.service;
import java.sql.SQLException;
import java.util.Scanner;
import com.kce.service.Student;
import com.kce.Dao.MarkSheetDetailsDAO;
import com.kce.Dao.StudentDetailsDAO;
import com.kce.bean.MarkSheetDetails;

public class Main {
	 static Scanner sc=new Scanner(System.in);
	  public static void main(String[] args) throws ClassNotFoundException, SQLException {
	System.out.println("If you are a Student enter 1");
	System.out.println("If you want to View Marksheet enter 2");
	int press = sc.nextInt();
	while (true) {
	if (press == 1) {
	System.out.println("Enter the choice:");
	System.out.println("1. Insert records");
	System.out.println("2. Update records");
	System.out.println("3. Delete records");
	System.out.println("4. Show records");
	System.out.println("5. Exit");
	int choice = sc.nextInt();
	sc.nextLine();
	switch (choice) {
	case 1:
	System.out.println("Enter the Number of Records to be inserted:");
	StudentDetailsDAO.insert(sc.nextInt());
	break;
	case 2:
	StudentDetailsDAO.update();
	break;
	case 3:
	StudentDetailsDAO.delete();
	break;
	case 4:
	StudentDetailsDAO.displayTable();
	break;

	case 5:
	System.out.println("Thank You");
	System.exit(0);
	break;

	default:
	System.out.println("Invalid choice");
	break;
	}

	} else if (press == 2) {
	while (true) {
	System.out.println("Enter the Choice");
	System.out.println("1. Student: ");
	System.out.println("2. Delete Rows");
	System.out.println("3. Update Data");
	System.out.println("4. Display Student Details");
	System.out.println("5. Exit");
	int choice = sc.nextInt();
	sc.nextLine();
	switch (choice) {
	case 1:
	StudentDetailsDAO.displayTable();
	System.out.println("Enter Subject Name: ");
	String name = sc.next();
	System.out.println("Enter the grade: ");
	double grade = sc.nextDouble();
	MarkSheetDetails marksheetDetails = new MarkSheetDetails(name, grade);
	MarkSheetDetailsDAO.Student(marksheetDetails);
	break;
	case 2:
	MarkSheetDetailsDAO.deleteRows();
	break;
	case 3:
	MarkSheetDetailsDAO.update();
	break;
	case 4:
	MarkSheetDetailsDAO.displayTable();
	break;
	case 5:
	System.out.println("Thank You");
	System.exit(0);
	break;
	default:
	System.out.println("Invalid choice");
	break;
	}
	 }
	  }
	   }
	    }
	  }


