package com.kce.service;
import com.kce.bean.MarkSheetDetails;
public class Student extends MarkSheetDetails{
	public Student(String subject, double grade) {
		super(subject,grade);
		}
}
