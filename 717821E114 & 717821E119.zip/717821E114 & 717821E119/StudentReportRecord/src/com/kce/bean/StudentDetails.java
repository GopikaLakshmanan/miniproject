package com.kce.bean;

public class StudentDetails {
	private String Name;
	private int StudentId;
	private String EmailId;
	private String DateOfBirth;
	
	public StudentDetails(String Name,int StudentId,String EmailId, String DateOfBirth )
	{
		super();
		this.Name=Name;
		this.StudentId=StudentId;
		this.EmailId=EmailId;
		this.DateOfBirth=DateOfBirth;
		
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public int getStudentId() {
		return StudentId;
	}

	public void setStudentId(int studentId) {
		StudentId = studentId;
	}

	public String getEmailId() {
		return EmailId;
	}

	public void setEmailId(String emailId) {
		EmailId = emailId;
	}

	public String getDateOfBirth() {
		return DateOfBirth;
	}

	public void setDateofbirth(String dateOfBirth) {
		DateOfBirth = dateOfBirth;
	}

	@Override
	public String toString() {
		return "StudentDetails [Name=" + Name + ", StudentId=" + StudentId + ", EmailId=" + EmailId + ", DateOfBirth="
				+ DateOfBirth + "]";
	}

	
	

	
	}

	

