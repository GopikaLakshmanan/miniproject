package com.kce.bean;

public class MarkSheetDetails {
	private String subject;
    private double grade;
    public MarkSheetDetails(String subject, double grade) {
   super();
   this.subject=subject;
   this.grade=grade;
    }
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public double getGrade() {
		return grade;
	}
	public void setGrade(double grade) {
		this.grade = grade;
	}
	@Override
	public String toString() {
		return "MarkSheetDetails [subject=" + subject + ", grade=" + grade + "]";
	}
	
}
