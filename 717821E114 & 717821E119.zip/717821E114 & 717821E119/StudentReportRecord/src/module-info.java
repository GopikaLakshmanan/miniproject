/**
 * 
 */
/**
 * @author ELCOT
 *
 */
module StudentReportRecord {
	requires java.sql;
}